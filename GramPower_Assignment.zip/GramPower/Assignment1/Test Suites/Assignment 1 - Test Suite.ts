<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Assignment 1 - Test Suite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>9d1681c2-996b-4925-8ddf-a24cb0537423</testSuiteGuid>
   <testCaseLink>
      <guid>ba5384c0-9d13-4eeb-a9fd-2c5f07067b38</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Scenario 1</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>f82254d1-2eb4-4e2b-abf0-dc807c9c3072</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Scenario 2</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>4774f2ff-6513-4846-8f0b-067cb70b2baf</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Scenario 3</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
